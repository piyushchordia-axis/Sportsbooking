
  # Sport Booking Platform

  This is a code bundle for Sport Booking Platform. The original project is available at https://www.figma.com/design/Zd9oUoFZDlhXw4HK6boxiL/Sport-Booking-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  