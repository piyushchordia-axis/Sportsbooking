# Sportline — Design Guidelines

## Stance
Data-dense operational with stadium-night energy. Every screen should feel like a floodlit indoor arena — functional, legible, alive with precise color signals.

## Color

| Token | Value | Usage |
|---|---|---|
| `--background` | `#070B14` | Page ground — deep midnight navy |
| `--card` | `#0D1424` | Cards, panels, modals |
| `--primary` | `#20D07A` | Electric green — available slots, CTAs, active states |
| `--accent` | `#F5A623` | Amber — high utilization, at-venue status, warnings |
| `--muted-foreground` | `#6A7D9C` | Labels, captions, secondary text |
| `--border` | `rgba(255,255,255,0.07)` | Hairline rules only |
| `--destructive` | `#E53E5A` | Cancelled, blocked, errors |

Use primary green sparingly for interactive elements and positive states. Amber for warnings and attention. Red for errors only.

## Typography

- **Display / Headings**: Rajdhani 600–700 — condensed, sporty, screen titles, venue names, large KPI numbers
- **Body**: DM Sans 400–500 — all prose and UI copy
- **Data / Labels**: DM Mono 400 — prices, IDs, times, stats, slot labels, percentages

## Component Patterns

### Cards
Dark `bg-card` with `border-border` hairline. On hover: `border-primary/35` with soft `shadow-primary/5`. Image overlays use `from-card/90 via-card/10 to-transparent`.

### Slot Grid
4-column grid. States:
- Available: `bg-primary/5 border-primary/20` → hover `bg-primary/15`
- Selected: `bg-primary border-primary shadow-primary/25`
- Booked: `bg-muted/20 border-border/40` reduced opacity
- Blocked: `bg-destructive/5 border-destructive/15`

### Status Badges
Pill, font-mono, background at 10% opacity. Green = confirmed, Amber = at-venue, Red = cancelled.

### Charts
Recharts BarChart — `#20D07A` bars, `rgba(255,255,255,0.04)` grid, `#6A7D9C` axes, dark card tooltip.

## Layout
- Max width `max-w-7xl`, `px-4` gutters
- Venue grid: 1 col → 2 col at md
- Booking: 2-col main + 1-col sticky summary at lg
- Dashboard: 2-col stats → 4-col at lg; 3+2 chart/utilization split
- `space-y-5` / `gap-4` between sections

## General Rules
- No inline styles except `fontFamily` for Rajdhani and `fontSize` for display type
- Use `font-mono` for all numeric data
- Keep `hide-scrollbar` on any horizontal scroll container
- Prefer `transition-all` with `duration-200` for hover states
