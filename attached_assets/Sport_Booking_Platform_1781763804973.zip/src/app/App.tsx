import { useState, useMemo } from "react";
import {
  Search, MapPin, Star, ChevronRight, Calendar, Users, TrendingUp,
  ArrowLeft, Check, Bell, Trophy, Zap, Plus, Activity,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";

// ─── Types ────────────────────────────────────────────────────────────────────

type Role = "player" | "owner";
type PlayerView = "discover" | "venue";
type Sport = "Football" | "Pickleball" | "Badminton" | "Box Cricket" | "Padel";
type SlotStatus = "available" | "booked" | "blocked" | "selected";

interface Venue {
  id: string;
  name: string;
  location: string;
  sports: Sport[];
  image: string;
  rating: number;
  reviewCount: number;
  basePrice: number;
  courts: Court[];
  distance: string;
}

interface Court {
  id: string;
  name: string;
  sport: Sport;
  capacity: number;
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const SPORTS: Sport[] = ["Football", "Pickleball", "Badminton", "Box Cricket", "Padel"];

const SPORT_COLORS: Record<Sport, string> = {
  Football: "bg-emerald-500/20 text-emerald-400",
  Pickleball: "bg-amber-500/20 text-amber-400",
  Badminton: "bg-blue-500/20 text-blue-400",
  "Box Cricket": "bg-red-500/20 text-red-400",
  Padel: "bg-purple-500/20 text-purple-400",
};

const SPORT_ICONS: Record<Sport, string> = {
  Football: "⚽",
  Pickleball: "🏓",
  Badminton: "🏸",
  "Box Cricket": "🏏",
  Padel: "🎾",
};

const VENUES: Venue[] = [
  {
    id: "v1",
    name: "The Arena Sports Hub",
    location: "Koramangala, Bengaluru",
    sports: ["Football", "Box Cricket"],
    image:
      "https://images.unsplash.com/photo-1776059462589-39863e08fbec?w=600&h=320&fit=crop&auto=format",
    rating: 4.8,
    reviewCount: 312,
    basePrice: 800,
    distance: "1.2 km",
    courts: [
      { id: "c1", name: "Turf A", sport: "Football", capacity: 10 },
      { id: "c2", name: "Turf B", sport: "Football", capacity: 10 },
      { id: "c3", name: "Box 1", sport: "Box Cricket", capacity: 8 },
    ],
  },
  {
    id: "v2",
    name: "Smash Zone Pickleball",
    location: "Indiranagar, Bengaluru",
    sports: ["Pickleball", "Badminton"],
    image:
      "https://images.unsplash.com/photo-1777382141965-68d47862eaf9?w=600&h=320&fit=crop&auto=format",
    rating: 4.6,
    reviewCount: 187,
    basePrice: 600,
    distance: "2.8 km",
    courts: [
      { id: "c4", name: "Court 1", sport: "Pickleball", capacity: 4 },
      { id: "c5", name: "Court 2", sport: "Pickleball", capacity: 4 },
      { id: "c6", name: "Court 3", sport: "Badminton", capacity: 2 },
    ],
  },
  {
    id: "v3",
    name: "Shuttle Masters Academy",
    location: "HSR Layout, Bengaluru",
    sports: ["Badminton"],
    image:
      "https://images.unsplash.com/photo-1761286753703-570ed91dd90e?w=600&h=320&fit=crop&auto=format",
    rating: 4.7,
    reviewCount: 243,
    basePrice: 450,
    distance: "3.5 km",
    courts: [
      { id: "c7", name: "Net 1", sport: "Badminton", capacity: 2 },
      { id: "c8", name: "Net 2", sport: "Badminton", capacity: 2 },
      { id: "c9", name: "Net 3", sport: "Badminton", capacity: 2 },
      { id: "c10", name: "Net 4", sport: "Badminton", capacity: 2 },
    ],
  },
  {
    id: "v4",
    name: "Apex Multi-Sport Centre",
    location: "Whitefield, Bengaluru",
    sports: ["Football", "Padel", "Pickleball"],
    image:
      "https://images.unsplash.com/photo-1771909713629-c261826a9f9f?w=600&h=320&fit=crop&auto=format",
    rating: 4.9,
    reviewCount: 441,
    basePrice: 1000,
    distance: "5.1 km",
    courts: [
      { id: "c11", name: "Turf 1", sport: "Football", capacity: 12 },
      { id: "c12", name: "Padel A", sport: "Padel", capacity: 4 },
      { id: "c13", name: "Padel B", sport: "Padel", capacity: 4 },
      { id: "c14", name: "Pickle 1", sport: "Pickleball", capacity: 4 },
    ],
  },
];

const TIME_SLOTS = [
  "06:00", "07:00", "08:00", "09:00", "10:00", "11:00",
  "12:00", "13:00", "14:00", "15:00", "16:00", "17:00",
  "18:00", "19:00", "20:00", "21:00", "22:00",
];

function getSlotPrice(time: string): number {
  const hour = parseInt(time);
  if (hour >= 6 && hour < 10) return 600;
  if (hour >= 10 && hour < 16) return 500;
  if (hour >= 16 && hour < 20) return 800;
  return 900;
}

function getSlotStatus(courtId: string, dayIdx: number, time: string): SlotStatus {
  const hour = parseInt(time);
  const seed = courtId.charCodeAt(courtId.length - 1) + dayIdx * 3 + hour;
  if (seed % 9 === 0) return "blocked";
  if (seed % 4 === 0 || seed % 6 === 0) return "booked";
  return "available";
}

const REVENUE_DATA = [
  { day: "Mon", revenue: 18400, bookings: 23 },
  { day: "Tue", revenue: 22100, bookings: 28 },
  { day: "Wed", revenue: 19800, bookings: 25 },
  { day: "Thu", revenue: 31200, bookings: 39 },
  { day: "Fri", revenue: 42800, bookings: 54 },
  { day: "Sat", revenue: 58600, bookings: 73 },
  { day: "Sun", revenue: 53200, bookings: 67 },
];

const RECENT_BOOKINGS = [
  { id: "BK-1841", player: "Arjun Mehta", court: "Turf A", sport: "Football" as Sport, time: "Sat, 19 Jun · 7:00 PM", amount: 800, status: "confirmed" },
  { id: "BK-1840", player: "Priya Sharma", court: "Court 1", sport: "Pickleball" as Sport, time: "Sat, 19 Jun · 6:00 PM", amount: 600, status: "confirmed" },
  { id: "BK-1839", player: "Rahul Nair", court: "Box 1", sport: "Box Cricket" as Sport, time: "Sat, 19 Jun · 5:00 PM", amount: 1600, status: "confirmed" },
  { id: "BK-1838", player: "Ananya Iyer", court: "Net 3", sport: "Badminton" as Sport, time: "Sat, 19 Jun · 4:00 PM", amount: 450, status: "pay-at-venue" },
  { id: "BK-1837", player: "Karan Patel", court: "Turf B", sport: "Football" as Sport, time: "Sat, 19 Jun · 3:00 PM", amount: 800, status: "confirmed" },
  { id: "BK-1836", player: "Sneha Reddy", court: "Padel A", sport: "Padel" as Sport, time: "Sat, 19 Jun · 2:00 PM", amount: 1200, status: "cancelled" },
];

const COURT_UTILIZATION = [
  { name: "Turf A", sport: "⚽", pct: 92 },
  { name: "Turf B", sport: "⚽", pct: 75 },
  { name: "Box 1", sport: "🏏", pct: 100 },
  { name: "Court 1", sport: "🏓", pct: 83 },
  { name: "Court 2", sport: "🏓", pct: 67 },
  { name: "Nets 1–4", sport: "🏸", pct: 88 },
  { name: "Padel A", sport: "🎾", pct: 58 },
];

// ─── Small Components ─────────────────────────────────────────────────────────

function SportBadge({ sport }: { sport: Sport }) {
  return (
    <span
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium ${SPORT_COLORS[sport]}`}
    >
      {SPORT_ICONS[sport]} {sport}
    </span>
  );
}

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  iconBg,
}: {
  label: string;
  value: string;
  sub: string;
  icon: React.ElementType;
  iconBg: string;
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-4 flex items-start gap-4">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${iconBg}`}>
        <Icon size={18} />
      </div>
      <div className="min-w-0">
        <p className="text-muted-foreground text-[10px] font-mono uppercase tracking-widest">{label}</p>
        <p
          className="text-foreground text-2xl font-bold leading-tight mt-0.5"
          style={{ fontFamily: "'Rajdhani', sans-serif" }}
        >
          {value}
        </p>
        <p className="text-muted-foreground text-xs mt-0.5">{sub}</p>
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [role, setRole] = useState<Role>("player");
  const [playerView, setPlayerView] = useState<PlayerView>("discover");
  const [selectedVenue, setSelectedVenue] = useState<Venue | null>(null);
  const [selectedCourt, setSelectedCourt] = useState<string | null>(null);
  const [selectedSport, setSelectedSport] = useState<Sport | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDay, setSelectedDay] = useState(0);
  const [selectedSlots, setSelectedSlots] = useState<Set<string>>(new Set());

  const weekDays = useMemo(() => {
    const today = new Date(2026, 5, 18);
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      return {
        label: d.toLocaleDateString("en-IN", { weekday: "short" }),
        date: d.getDate(),
        month: d.toLocaleDateString("en-IN", { month: "short" }),
      };
    });
  }, []);

  const filteredVenues = useMemo(
    () =>
      VENUES.filter((v) => {
        const matchSport = !selectedSport || v.sports.includes(selectedSport);
        const matchSearch =
          !searchQuery ||
          v.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          v.location.toLowerCase().includes(searchQuery.toLowerCase());
        return matchSport && matchSearch;
      }),
    [selectedSport, searchQuery]
  );

  const activeCourt = useMemo(
    () =>
      selectedVenue && selectedCourt
        ? selectedVenue.courts.find((c) => c.id === selectedCourt) ?? null
        : null,
    [selectedVenue, selectedCourt]
  );

  const totalAmount = useMemo(
    () =>
      Array.from(selectedSlots).reduce((sum, key) => {
        const [, , time] = key.split("|");
        return sum + getSlotPrice(time);
      }, 0),
    [selectedSlots]
  );

  function openVenue(venue: Venue) {
    setSelectedVenue(venue);
    setSelectedCourt(venue.courts[0].id);
    setSelectedSlots(new Set());
    setPlayerView("venue");
  }

  function toggleSlot(time: string) {
    const key = `${selectedCourt}|${selectedDay}|${time}`;
    const status = getSlotStatus(selectedCourt!, selectedDay, time);
    if (status !== "available" && !selectedSlots.has(key)) return;
    setSelectedSlots((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  }

  function switchRole(r: Role) {
    setRole(r);
    setPlayerView("discover");
    setSelectedVenue(null);
    setSelectedSport(null);
    setSearchQuery("");
  }

  return (
    <div className="min-h-screen bg-background" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* ── Nav ── */}
      <nav className="sticky top-0 z-50 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center gap-3">
          {/* Logo */}
          <div className="flex items-center gap-2 mr-3 flex-shrink-0">
            <div className="w-7 h-7 bg-primary rounded-md flex items-center justify-center">
              <Zap size={14} className="text-primary-foreground" fill="currentColor" />
            </div>
            <span
              className="text-foreground font-bold tracking-wider"
              style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.15rem", letterSpacing: "0.06em" }}
            >
              SPORTLINE
            </span>
          </div>

          {/* Role switcher */}
          <div className="flex items-center gap-0.5 bg-muted rounded-lg p-1">
            {(["player", "owner"] as Role[]).map((r) => (
              <button
                key={r}
                onClick={() => switchRole(r)}
                className={`px-3 py-1 rounded-md text-sm font-medium capitalize transition-all ${
                  role === r
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {r === "player" ? "Player" : "Owner"}
              </button>
            ))}
          </div>

          {/* Search */}
          {role === "player" && playerView === "discover" && (
            <div className="flex-1 max-w-xs relative ml-2">
              <Search
                size={13}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
              />
              <input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search venues, locations…"
                className="w-full bg-muted text-foreground text-sm pl-8 pr-3 py-1.5 rounded-lg border border-transparent focus:border-primary/40 focus:outline-none placeholder:text-muted-foreground"
              />
            </div>
          )}

          <div className="ml-auto flex items-center gap-2">
            <button className="w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted transition-colors relative">
              <Bell size={15} />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-primary" />
            </button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/50 to-primary flex items-center justify-center text-[11px] font-bold text-primary-foreground flex-shrink-0">
              {role === "player" ? "AR" : "RK"}
            </div>
          </div>
        </div>
      </nav>

      {/* ── Content ── */}
      {role === "player" ? (
        playerView === "discover" ? (
          <PlayerDiscovery
            venues={filteredVenues}
            selectedSport={selectedSport}
            onSelectSport={setSelectedSport}
            onOpenVenue={openVenue}
          />
        ) : selectedVenue ? (
          <VenueBooking
            venue={selectedVenue}
            selectedCourt={selectedCourt}
            onSelectCourt={(id) => {
              setSelectedCourt(id);
              setSelectedSlots(new Set());
            }}
            weekDays={weekDays}
            selectedDay={selectedDay}
            onSelectDay={setSelectedDay}
            selectedSlots={selectedSlots}
            onToggleSlot={toggleSlot}
            totalAmount={totalAmount}
            onBack={() => {
              setPlayerView("discover");
              setSelectedVenue(null);
            }}
            activeCourt={activeCourt}
          />
        ) : null
      ) : (
        <OwnerDashboard />
      )}
    </div>
  );
}

// ─── Player Discovery ─────────────────────────────────────────────────────────

function PlayerDiscovery({
  venues,
  selectedSport,
  onSelectSport,
  onOpenVenue,
}: {
  venues: Venue[];
  selectedSport: Sport | null;
  onSelectSport: (s: Sport | null) => void;
  onOpenVenue: (v: Venue) => void;
}) {
  return (
    <div>
      {/* Hero */}
      <div className="relative h-52 overflow-hidden flex items-end">
        <img
          src="https://images.unsplash.com/photo-1776059462589-39863e08fbec?w=1400&h=420&fit=crop&auto=format"
          alt="Rooftop sports courts illuminated at night"
          className="absolute inset-0 w-full h-full object-cover object-center opacity-25"
        />
        <div
          className="absolute inset-0"
          style={{ background: "linear-gradient(to top, #070B14 30%, transparent 100%)" }}
        />
        <div className="relative max-w-7xl mx-auto px-4 pb-7 w-full">
          <h1
            className="text-foreground font-bold leading-none"
            style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "2.4rem", letterSpacing: "0.02em" }}
          >
            Book Your Next Game
          </h1>
          <p className="text-muted-foreground text-sm mt-1.5">
            {venues.length} venues · Bengaluru · Instant confirmation
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-5">
        {/* Sport filter pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 hide-scrollbar">
          <button
            onClick={() => onSelectSport(null)}
            className={`flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-medium border transition-all ${
              !selectedSport
                ? "bg-primary text-primary-foreground border-primary"
                : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/25"
            }`}
          >
            All Sports
          </button>
          {SPORTS.map((s) => (
            <button
              key={s}
              onClick={() => onSelectSport(selectedSport === s ? null : s)}
              className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-1.5 rounded-full text-sm font-medium border transition-all ${
                selectedSport === s
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/25"
              }`}
            >
              <span>{SPORT_ICONS[s]}</span>
              {s}
            </button>
          ))}
        </div>

        {/* Venue grid */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
          {venues.map((venue) => (
            <VenueCard key={venue.id} venue={venue} onOpen={() => onOpenVenue(venue)} />
          ))}
        </div>

        {venues.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <Trophy size={32} className="mx-auto mb-3 opacity-20" />
            <p className="font-medium text-foreground/60">No venues found</p>
            <p className="text-sm mt-1">Try adjusting your filters</p>
          </div>
        )}
      </div>
    </div>
  );
}

function VenueCard({ venue, onOpen }: { venue: Venue; onOpen: () => void }) {
  return (
    <div
      onClick={onOpen}
      className="bg-card border border-border rounded-xl overflow-hidden cursor-pointer group hover:border-primary/35 transition-all duration-200 hover:shadow-xl hover:shadow-primary/5"
    >
      <div className="relative h-44 overflow-hidden bg-muted">
        <img
          src={venue.image}
          alt={`${venue.name} sports facility`}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card/90 via-card/10 to-transparent" />
        <div className="absolute top-3 right-3 bg-background/75 backdrop-blur-sm text-foreground px-2 py-0.5 rounded text-xs font-mono">
          from ₹{venue.basePrice}/hr
        </div>
        <div className="absolute bottom-3 left-3 flex gap-1.5 flex-wrap">
          {venue.sports.map((s) => (
            <SportBadge key={s} sport={s} />
          ))}
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3
              className="text-foreground font-semibold truncate"
              style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.1rem" }}
            >
              {venue.name}
            </h3>
            <p className="text-muted-foreground text-xs mt-0.5 flex items-center gap-1">
              <MapPin size={10} />
              {venue.location} · {venue.distance}
            </p>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            <Star size={11} className="text-amber-400 fill-amber-400" />
            <span className="text-foreground text-sm font-mono font-medium">{venue.rating}</span>
            <span className="text-muted-foreground text-xs font-mono">({venue.reviewCount})</span>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Users size={11} /> {venue.courts.length} courts
            </span>
            <span className="flex items-center gap-1.5 text-primary text-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block animate-pulse" />
              Open now
            </span>
          </div>
          <span className="text-primary text-xs font-medium flex items-center gap-0.5 group-hover:gap-1.5 transition-all">
            Book now <ChevronRight size={12} />
          </span>
        </div>
      </div>
    </div>
  );
}

// ─── Venue Booking ────────────────────────────────────────────────────────────

function VenueBooking({
  venue,
  selectedCourt,
  onSelectCourt,
  weekDays,
  selectedDay,
  onSelectDay,
  selectedSlots,
  onToggleSlot,
  totalAmount,
  onBack,
  activeCourt,
}: {
  venue: Venue;
  selectedCourt: string | null;
  onSelectCourt: (id: string) => void;
  weekDays: { label: string; date: number; month: string }[];
  selectedDay: number;
  onSelectDay: (i: number) => void;
  selectedSlots: Set<string>;
  onToggleSlot: (time: string) => void;
  totalAmount: number;
  onBack: () => void;
  activeCourt: Court | null;
}) {
  return (
    <div className="max-w-7xl mx-auto px-4 py-5">
      <button
        onClick={onBack}
        className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground text-sm mb-4 transition-colors"
      >
        <ArrowLeft size={13} /> Back to venues
      </button>

      {/* Venue header image */}
      <div className="relative h-44 rounded-xl overflow-hidden mb-6 bg-muted">
        <img src={venue.image} alt={venue.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/50 to-transparent" />
        <div className="absolute inset-0 flex items-end p-5">
          <div>
            <h2
              className="text-foreground font-bold"
              style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.75rem" }}
            >
              {venue.name}
            </h2>
            <p className="text-muted-foreground text-sm flex items-center gap-2 mt-1">
              <MapPin size={11} /> {venue.location}
              <span className="opacity-40">·</span>
              <Star size={11} className="text-amber-400 fill-amber-400" />
              <span className="font-mono">{venue.rating}</span>
              <span className="font-mono text-xs">({venue.reviewCount})</span>
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Court selector */}
          <section>
            <p className="text-muted-foreground text-[10px] font-mono uppercase tracking-widest mb-2">
              Select Court
            </p>
            <div className="flex flex-wrap gap-2">
              {venue.courts.map((court) => (
                <button
                  key={court.id}
                  onClick={() => onSelectCourt(court.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition-all ${
                    selectedCourt === court.id
                      ? "bg-primary/10 border-primary/70 text-primary"
                      : "border-border text-muted-foreground hover:border-foreground/20 hover:text-foreground"
                  }`}
                >
                  <span>{SPORT_ICONS[court.sport]}</span>
                  <span className="font-medium">{court.name}</span>
                  <span className="text-[11px] opacity-50">{court.sport}</span>
                </button>
              ))}
            </div>
          </section>

          {/* Day selector */}
          <section>
            <p className="text-muted-foreground text-[10px] font-mono uppercase tracking-widest mb-2">
              Select Date
            </p>
            <div className="flex gap-2 overflow-x-auto pb-1 hide-scrollbar">
              {weekDays.map((d, i) => (
                <button
                  key={i}
                  onClick={() => onSelectDay(i)}
                  className={`flex-shrink-0 flex flex-col items-center px-3 py-2 rounded-lg border min-w-[52px] transition-all ${
                    selectedDay === i
                      ? "bg-primary text-primary-foreground border-primary"
                      : "border-border text-muted-foreground hover:border-foreground/25 hover:text-foreground"
                  }`}
                >
                  <span className="text-[10px] font-mono uppercase opacity-75">{d.label}</span>
                  <span
                    className="text-xl font-bold leading-tight"
                    style={{ fontFamily: "'Rajdhani', sans-serif" }}
                  >
                    {d.date}
                  </span>
                  <span className="text-[10px] font-mono opacity-60">{d.month}</span>
                </button>
              ))}
            </div>
          </section>

          {/* Slot grid */}
          <section>
            <div className="flex items-center justify-between mb-2">
              <p className="text-muted-foreground text-[10px] font-mono uppercase tracking-widest">
                Available Slots
              </p>
              <div className="flex items-center gap-3 text-[10px] text-muted-foreground font-mono">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-sm bg-primary/25 border border-primary/40 inline-block" />
                  Available
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-sm bg-foreground/8 border border-border inline-block" />
                  Booked
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded-sm bg-primary inline-block" />
                  Selected
                </span>
              </div>
            </div>
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
              {TIME_SLOTS.map((time) => {
                const key = `${selectedCourt}|${selectedDay}|${time}`;
                const status: SlotStatus = selectedSlots.has(key)
                  ? "selected"
                  : getSlotStatus(selectedCourt!, selectedDay, time);
                const price = getSlotPrice(time);

                return (
                  <button
                    key={time}
                    onClick={() => onToggleSlot(time)}
                    disabled={status === "booked" || status === "blocked"}
                    className={[
                      "flex flex-col items-center justify-center p-2.5 rounded-lg border text-xs transition-all",
                      status === "selected"
                        ? "bg-primary border-primary text-primary-foreground shadow-md shadow-primary/25"
                        : status === "available"
                        ? "bg-primary/5 border-primary/20 text-foreground hover:bg-primary/15 hover:border-primary/50 cursor-pointer"
                        : status === "booked"
                        ? "bg-muted/20 border-border/40 text-muted-foreground/35 cursor-not-allowed"
                        : "bg-destructive/5 border-destructive/15 text-muted-foreground/25 cursor-not-allowed",
                    ].join(" ")}
                  >
                    <span className="font-mono font-medium">{time}</span>
                    {status !== "booked" && status !== "blocked" && (
                      <span
                        className={`font-mono text-[10px] mt-0.5 ${
                          status === "selected" ? "text-primary-foreground/75" : "text-muted-foreground"
                        }`}
                      >
                        ₹{price}
                      </span>
                    )}
                    {status === "booked" && (
                      <span className="text-[9px] mt-0.5 font-mono">FULL</span>
                    )}
                    {status === "blocked" && (
                      <span className="text-[9px] mt-0.5 font-mono text-destructive/40">—</span>
                    )}
                  </button>
                );
              })}
            </div>
          </section>
        </div>

        {/* Booking summary */}
        <div className="lg:col-span-1">
          <div className="bg-card border border-border rounded-xl p-5 sticky top-20">
            <h3
              className="text-foreground font-semibold mb-4"
              style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.1rem" }}
            >
              Booking Summary
            </h3>

            {activeCourt && (
              <div className="flex items-center gap-2.5 mb-4 pb-4 border-b border-border">
                <span className="text-2xl">{SPORT_ICONS[activeCourt.sport]}</span>
                <div>
                  <p className="text-foreground text-sm font-medium">{activeCourt.name}</p>
                  <p className="text-muted-foreground text-xs">
                    {activeCourt.sport} · {activeCourt.capacity} players max
                  </p>
                </div>
              </div>
            )}

            {selectedSlots.size === 0 ? (
              <p className="text-muted-foreground text-sm text-center py-6 leading-relaxed">
                Select time slots<br />to continue
              </p>
            ) : (
              <div className="space-y-2 mb-4 max-h-40 overflow-y-auto hide-scrollbar">
                {Array.from(selectedSlots).map((key) => {
                  const parts = key.split("|");
                  const time = parts[2];
                  const dayIdx = parseInt(parts[1]);
                  const day = { label: weekDays[dayIdx]?.label, date: weekDays[dayIdx]?.date };
                  return (
                    <div key={key} className="flex items-center justify-between text-sm">
                      <span>
                        <span className="text-foreground font-mono">{time}</span>
                        <span className="text-muted-foreground text-xs ml-2">
                          {day.label} {day.date}
                        </span>
                      </span>
                      <span className="text-foreground font-mono text-xs">₹{getSlotPrice(time)}</span>
                    </div>
                  );
                })}
              </div>
            )}

            {selectedSlots.size > 0 && (
              <>
                <div className="border-t border-border pt-3 mb-4 space-y-1.5">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{selectedSlots.size} slot(s)</span>
                    <span className="font-mono">₹{totalAmount}</span>
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Platform fee</span>
                    <span className="font-mono text-primary">Free</span>
                  </div>
                  <div className="flex justify-between font-semibold pt-2 border-t border-border">
                    <span className="text-foreground text-sm">Total</span>
                    <span
                      className="text-primary font-mono"
                      style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.3rem" }}
                    >
                      ₹{totalAmount.toLocaleString("en-IN")}
                    </span>
                  </div>
                </div>
                <button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-2.5 rounded-lg font-semibold text-sm transition-all hover:shadow-lg hover:shadow-primary/20 active:scale-[0.98]">
                  Confirm & Pay
                </button>
                <button className="w-full mt-2 text-muted-foreground hover:text-foreground py-2 rounded-lg text-sm transition-colors hover:bg-muted">
                  Pay at venue
                </button>
              </>
            )}

            <div className="mt-4 pt-4 border-t border-border space-y-2">
              {[
                "Free cancellation up to 4 hrs before",
                "Instant booking confirmation",
                "Earn loyalty points every booking",
              ].map((item) => (
                <div key={item} className="flex items-start gap-2 text-xs text-muted-foreground">
                  <Check size={11} className="text-primary mt-0.5 flex-shrink-0" />
                  {item}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Owner Dashboard ──────────────────────────────────────────────────────────

function OwnerDashboard() {
  const [activeVenue, setActiveVenue] = useState("all");

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2
            className="text-foreground font-bold"
            style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1.6rem" }}
          >
            Dashboard
          </h2>
          <p className="text-muted-foreground text-xs font-mono mt-0.5">
            Thu 18 Jun 2026 · Week 25
          </p>
        </div>
        <div className="flex items-center gap-2">
          <select
            value={activeVenue}
            onChange={(e) => setActiveVenue(e.target.value)}
            className="bg-card border border-border text-foreground text-sm px-3 py-1.5 rounded-lg focus:outline-none focus:border-primary/40 cursor-pointer"
          >
            <option value="all">All Venues</option>
            <option value="v1">The Arena Sports Hub</option>
            <option value="v4">Apex Multi-Sport Centre</option>
          </select>
          <button className="flex items-center gap-1.5 bg-primary text-primary-foreground px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
            <Plus size={13} /> New Booking
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          label="Today's Revenue"
          value="₹58,600"
          sub="+12% vs yesterday"
          icon={TrendingUp}
          iconBg="bg-primary/10 text-primary"
        />
        <StatCard
          label="Active Bookings"
          value="73"
          sub="54 prepaid · 19 at-venue"
          icon={Calendar}
          iconBg="bg-blue-500/10 text-blue-400"
        />
        <StatCard
          label="Occupancy"
          value="84%"
          sub="11 of 13 courts active"
          icon={Activity}
          iconBg="bg-amber-500/10 text-amber-400"
        />
        <StatCard
          label="Members"
          value="1,247"
          sub="38 new this week"
          icon={Users}
          iconBg="bg-purple-500/10 text-purple-400"
        />
      </div>

      {/* Chart + utilization */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Revenue chart */}
        <div className="lg:col-span-3 bg-card border border-border rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3
              className="text-foreground font-semibold"
              style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1rem" }}
            >
              Weekly Revenue
            </h3>
            <span className="text-muted-foreground text-[10px] font-mono">Jun 12 – 18, 2026</span>
          </div>
          <ResponsiveContainer width="100%" height={175}>
            <BarChart data={REVENUE_DATA} barSize={18} margin={{ top: 0, right: 0, left: -10, bottom: 0 }}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="rgba(255,255,255,0.04)"
                vertical={false}
              />
              <XAxis
                dataKey="day"
                tick={{ fontSize: 11, fill: "#6A7D9C", fontFamily: "DM Mono, monospace" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 10, fill: "#6A7D9C", fontFamily: "DM Mono, monospace" }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
              />
              <Tooltip
                contentStyle={{
                  background: "#0D1424",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: 8,
                  fontSize: 12,
                  fontFamily: "DM Mono, monospace",
                }}
                formatter={(val: number) => [`₹${val.toLocaleString("en-IN")}`, "Revenue"]}
                labelStyle={{ color: "#E8EDF8", marginBottom: 4 }}
                cursor={{ fill: "rgba(255,255,255,0.025)" }}
              />
              <Bar dataKey="revenue" fill="#20D07A" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Court utilization */}
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-5">
          <h3
            className="text-foreground font-semibold mb-4"
            style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1rem" }}
          >
            Today"s Utilization
          </h3>
          <div className="space-y-3">
            {COURT_UTILIZATION.map((court) => (
              <div key={court.name} className="flex items-center gap-3">
                <span className="text-sm w-5 flex-shrink-0">{court.sport}</span>
                <span className="text-muted-foreground text-xs font-mono w-16 flex-shrink-0 truncate">
                  {court.name}
                </span>
                <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${court.pct}%`,
                      background:
                        court.pct >= 90
                          ? "#F5A623"
                          : court.pct >= 70
                          ? "#20D07A"
                          : "#3B82F6",
                    }}
                  />
                </div>
                <span className="text-xs font-mono text-muted-foreground w-8 text-right flex-shrink-0">
                  {court.pct}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent bookings table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <h3
            className="text-foreground font-semibold"
            style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: "1rem" }}
          >
            Recent Bookings
          </h3>
          <button className="text-primary text-xs font-medium hover:underline">View all</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                {["Booking ID", "Player", "Court", "Time", "Amount", "Status"].map((h) => (
                  <th
                    key={h}
                    className="px-5 py-3 text-left text-[10px] font-mono text-muted-foreground uppercase tracking-widest whitespace-nowrap"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {RECENT_BOOKINGS.map((b, i) => (
                <tr
                  key={b.id}
                  className={`hover:bg-muted/15 transition-colors ${
                    i < RECENT_BOOKINGS.length - 1 ? "border-b border-border/40" : ""
                  }`}
                >
                  <td className="px-5 py-3 font-mono text-muted-foreground text-xs">{b.id}</td>
                  <td className="px-5 py-3 text-foreground font-medium whitespace-nowrap">{b.player}</td>
                  <td className="px-5 py-3">
                    <span className="flex items-center gap-1.5 text-muted-foreground text-xs">
                      {SPORT_ICONS[b.sport]} {b.court}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-muted-foreground text-xs font-mono whitespace-nowrap">
                    {b.time}
                  </td>
                  <td className="px-5 py-3 text-foreground font-mono text-sm font-medium">
                    ₹{b.amount.toLocaleString("en-IN")}
                  </td>
                  <td className="px-5 py-3">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium font-mono ${
                        b.status === "confirmed"
                          ? "bg-primary/10 text-primary"
                          : b.status === "pay-at-venue"
                          ? "bg-amber-500/10 text-amber-400"
                          : "bg-destructive/10 text-destructive"
                      }`}
                    >
                      {b.status === "confirmed"
                        ? "Confirmed"
                        : b.status === "pay-at-venue"
                        ? "At Venue"
                        : "Cancelled"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
